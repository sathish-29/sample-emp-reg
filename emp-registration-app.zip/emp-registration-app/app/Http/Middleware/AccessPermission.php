<?php

namespace App\Http\Middleware;

use App\User;
use App\UserRole;
use Auth;
use Closure;

class AccessPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $user = Auth::user();

        // Check user role
        $userRole = UserRole::where('id',$user->user_role_id)->first();
        
        if ($userRole && $userRole->role_name != 'manager') {
            Auth::logout();
            return redirect('/')->with('error', "This user doesn't have permission to access this page.");
        }
        

        return $next($request);
    }
}
