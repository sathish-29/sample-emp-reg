<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Skill;
use App\EmployeeSkill;


class EmployeeSkillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $skills = EmployeeSkill::join('skills','skills.id','employee_skills.skill_id')
            ->where('employee_skills.user_id', auth()->id())
            ->paginate(5);

        return view('employee_skills/index', ['skills' => $skills]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employee_skills/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        EmployeeSkill::create([
            'skill_id' => 1,
            'user_id' => auth()->id(),
            'percentage' => 1
        ]);

        return redirect()->intended('employee-skills');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $skill = EmployeeSkill::join('skills','skills.id','employee_skills.skill_id')
            ->where('employee_skills.id', $id);

        return view('employee_skills/edit', ['skill' => $skill]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = [
            'percentage' => $request['percentage']
        ];
        EmployeeSkill::where('id', $id)
            ->update($input);        
        return redirect()->intended('employee-skills');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        EmployeeSkill::where('id', $id)->delete();
        return redirect()->intended('employee-skills');
    }
}
