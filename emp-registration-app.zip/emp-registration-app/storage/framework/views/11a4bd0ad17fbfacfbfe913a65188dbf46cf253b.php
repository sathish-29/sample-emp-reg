  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

  <?php 
      $isVerifiedEmployer = \App\User::isVerifiedEmployer();
     ?>

   

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset("/bower_components/AdminLTE/dist/img/avatar5.png")); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
        </div>
      </div>

      <ul class="sidebar-menu">
        <li class="active"><a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>

        <?php if( ! $isVerifiedEmployer): ?>
        <li><a href="<?php echo e(url('employee-management')); ?>"><i class="fa fa-link"></i> <span>Employee Details</span></a></li>
          <li><a href="<?php echo e(route('skill-management.index')); ?>"><i class="fa fa-link"></i> <span>Skill Details</span></a></li>
        <?php endif; ?>
        </ul>
    </section>
  </aside>