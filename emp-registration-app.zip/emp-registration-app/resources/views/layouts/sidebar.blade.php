  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

  @php
      $isVerifiedEmployer = \App\User::isVerifiedEmployer();
    @endphp

   

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="{{ asset("/bower_components/AdminLTE/dist/img/avatar5.png") }}" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{ Auth::user()->name}}</p>
        </div>
      </div>

      <ul class="sidebar-menu">
        <li class="active"><a href="{{ url('/dashboard') }}"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>

        @if( ! $isVerifiedEmployer)
        <li><a href="{{ url('employee-management') }}"><i class="fa fa-link"></i> <span>Employee Details</span></a></li>
          <li><a href="{{ route('skill-management.index') }}"><i class="fa fa-link"></i> <span>Skill Details</span></a></li>
        @endif
        </ul>
    </section>
  </aside>